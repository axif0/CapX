 
from django.contrib import admin
from django.urls import path
from bug.views import *


urlpatterns = [
    path("" ,home ,name="home"),
    path("suc-cese/" ,succese ,name="succese"),

    path("delete-bug/<id>/", delete_bug, name="delete_bug"),

    path("update-bug/<id>/" ,update_bug, name="update_bug"),

    path('admin/', admin.site.urls),

]

