from django.db import models

class Bug(models.Model):
    bugTitle = models.CharField(max_length=200)
    bugDescription = models.TextField()
    tag = models.CharField(max_length=50)
    subscribers = models.CharField(max_length=200)
    assign_to = models.CharField(max_length=100)

    def __str__(self):
        return self.bugTitle