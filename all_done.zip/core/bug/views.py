from django.shortcuts import render, redirect
from django.http import HttpResponse
from .demo import bugs
from .models import *


def succese(request):
    # return render(request, "home/all_bugs.html")
    queryset = Bug.objects.all()

    search_query = request.GET.get('search')
    if search_query:
        queryset = queryset.filter(bugTitle__icontains=search_query)

    context = {'home': queryset}
    return render(request, "home/all_bugs.html", context)


def home(request):
    if request.method == "POST":
        data = request.POST
        bugTitle = data.get('bugTitle')
        bugDescription = data.get('bugDescription')
        tag = data.get('tag')
        subscribers = data.get('subscribers')
        assign_to = data.get('assign_to')

        Bug.objects.create(
            bugTitle=bugTitle,
            bugDescription=bugDescription,
            tag=tag,
            subscribers=subscribers,
            assign_to=assign_to
        )
        return redirect('/')

    queryset = Bug.objects.all()

    if request.GET.get('search'):
        queryset=queryset.filter(bugTitle__icontains = request.GET.get('search'))


    context = {'home': queryset}
    return render(request, "home/register_bug.html", context)


def delete_bug(request,id):
    queryset = Bug.objects.get(id=id)
    queryset.delete()
    return redirect('/suc-cese/')


def update_bug(request,id):
    queryset = Bug.objects.get(id=id)
    print(queryset)

    if request.method == "POST":
        data = request.POST
        bugTitle = data.get('bugTitle')
        bugDescription = data.get('bugDescription')
        tag = data.get('tag')
        subscribers = data.get('subscribers')
        assign_to = data.get('assign_to')

        queryset.bugTitle = bugTitle
        queryset.bugDescription = bugDescription
        queryset.tag = tag
        queryset.subscribers = subscribers
        queryset.assign_to = assign_to

        queryset.save()
        return redirect('/suc-cese/')

    context = {'home': queryset}
    return render(request, "home/update_bug.html", context)

